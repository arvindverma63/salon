<!DOCTYPE html>
<html>
<head>
    <title>Email Verification</title>
</head>
<body>
    <h1>Verify Your Email Address</h1>
    <p>Click the link below to verify your email address:</p>
    <a href="<?php echo e(url('api/verify-email/' . $token)); ?>">Verify Email</a>
</body>
</html>
<?php /**PATH C:\Users\Hp\Desktop\tann\resources\views/emails/verify.blade.php ENDPATH**/ ?>