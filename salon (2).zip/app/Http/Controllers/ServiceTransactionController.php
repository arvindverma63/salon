<?php

namespace App\Http\Controllers;

use App\Models\Service;
use Illuminate\Http\Request;
use App\Models\ServiceTransaction;
use App\Models\User_profile;
use Illuminate\Support\Facades\DB;
use App\Models\Location;

class ServiceTransactionController extends Controller
{
    /**
     * @OA\Get(
     *     path="/api/service-transactions",
     *     summary="Get all service transactions",
     *     tags={"Service Transactions"},
     *     description="Retrieve a list of all service transactions.",
     *     @OA\Response(
     *         response=200,
     *         description="Successful operation"
     *     )
     * )
     */
    //     public function index()
    // {
    //     // Fetch all service transactions
    //     $serviceTransactions = DB::table('service_transactions')->get();

    //     // If no service transactions found, return an error
    //     if ($serviceTransactions->isEmpty()) {
    //         return response()->json(['message' => 'No service transactions found'], 404);
    //     }

    //     // Assuming you want to loop through each transaction to get related user profiles and services
    //     $result = [];

    //     foreach ($serviceTransactions as $transaction) {
    //         $id = $transaction->user_id; // Assuming you want to fetch by user_id

    //         // Fetch the user profile data
    //         $userProfile = User_profile::select('firstName', 'lastName', 'available_balance')
    //             ->where('user_id', $id)
    //             ->first(); // Use first() to get a single record

    //         // If no user profile found, skip this transaction
    //         if (!$userProfile) {
    //             continue; // Or return an error for this specific case if needed
    //         }

    //         // Fetch the service details
    //         $serviceDetails = Service::select('serviceName', 'price', 'minutesAvailable')
    //             ->where('id', $transaction->service_id) // Assuming 'service_id' is in the transaction
    //             ->first(); // Fetch a single record related to the service transaction

    //         // If no service details found, skip this transaction
    //         if (!$serviceDetails) {
    //             continue; // Or return an error for this specific case if needed
    //         }

    //         // Combine the data for this transaction
    //         $result[] = [
    //             'service_transaction' => $transaction,
    //             'user_profile' => $userProfile,
    //             'service' => $serviceDetails
    //         ];
    //     }

    //     // If no result is populated, return an error
    //     if (empty($result)) {
    //         return response()->json(['message' => 'No valid data found'], 404);
    //     }

    //     // Return the combined data as a JSON response
    //     return response()->json($result);
    // }
    public function index()
    {
        // Fetch all product transactions
        $transactions = ServiceTransaction::all();

        // Check if no transactions found
        if ($transactions->isEmpty()) {
            return response()->json(['error' => 'No service transactions found'], 404);
        }

        $result = [];

        // Loop through each transaction
        foreach ($transactions as $transaction) {
            $userId = $transaction->user_id; // Assuming 'user_id' exists in the transaction

            // Fetch the user profile data
            $userProfile = User_profile::select('user_id as _id', 'firstName', 'lastName', 'email', 'phone_number', 'available_balance', 'preferred_location')
                ->where('user_id', $userId)
                ->first(); // Use first() to get a single record

            // If user profile not found, continue to the next transaction
            if (!$userProfile) {
                continue;
            }

            // Fetch the preferred location details
            $preferredLocation = Location::select('id as id', 'name', 'address', 'city', 'phone_number', 'post_code')
                ->where('id', $userProfile->preferred_location) // Use preferred_location_id from user profile
                ->first();

            // Fetch the product details
            $service = Service::select('id as _id', 'serviceName', 'price')
                ->where('id', $transaction->service_id) // Assuming 'product_id' exists in the transaction
                ->first();

            // If product not found, continue to the next transaction
            if (!$service) {
                continue;
            }

            // Add the transaction data to the result array
            $result[] = [
                'user_details' => [
                    'id' => $userProfile->_id,
                    'firstName' => $userProfile->firstName,
                    'lastName' => $userProfile->lastName,
                    'email' => $userProfile->email,
                    'phone_number' => $userProfile->phone_number,
                    'available_balance' => $userProfile->available_balance,
                    'preferred_location' => $preferredLocation ? [
                        'id' => $preferredLocation->_id,
                        'name' => $preferredLocation->name,
                        'address' => $preferredLocation->address,
                        'city' => $preferredLocation->city,
                        'phone_number' => $preferredLocation->phone_number,
                        'post_code' => $preferredLocation->post_code,
                    ] : null, // Handle case where preferred location may not exist
                ],
                'service' => [
                    'id' => $service->_id,
                    'name' => $service->serviceName,
                    'price' => $service->price,
                ],
                'transaction' => [
                    'id' => $transaction->id, // Assuming your transaction model has an id field
                    'quantity' => $transaction->quantity, // Assuming you have a 'quantity' field in the transaction
                    'type' => $transaction->type,
                    'created_at' => $transaction->created_at,
                    'updated_at' => $transaction->updated_at,
                ],
            ];
        }

        // If no valid transactions were found, return an error
        if (empty($result)) {
            return response()->json(['error' => 'No valid service transactions found'], 404);
        }

        // Return the combined data as a JSON response
        return response()->json($result);
    }



    /**
     * @OA\Post(
     *     path="/api/service-transactions",
     *     summary="Create a new service transaction",
     *     tags={"Service Transactions"},
     *     description="Store a new service transaction in the database.",
     *     @OA\RequestBody(
     *         required=true,
     *         @OA\JsonContent(
     *             @OA\Property(property="user_id", type="string", example="123"),
     *             @OA\Property(property="quantity", type="string", example="2"),
     *             @OA\Property(property="type", type="string", example="purchase"),
     *             @OA\Property(property="location", type="string", example="New York"),
     *             @OA\Property(property="service", type="string", example="Haircut")
     *         )
     *     ),
     *     @OA\Response(
     *         response=201,
     *         description="Service transaction created successfully"
     *     ),
     *     @OA\Response(
     *         response=422,
     *         description="Validation error"
     *     )
     * )
     */
    public function store(Request $request)
    {
        $request->validate([
            'user_id' => 'required|integer',
            'type' => 'nullable|string|in:purchased,used', // Only allow 'purchased' or 'used'
            'location' => 'nullable|integer',
            'service_id' => 'nullable|integer',
        ]);

        // Check if the service exists
        $service = Service::find($request->service_id);
        if (!$service) {
            return response()->json(['error' => 'Service not found'], 404);
        }

        $serviceQuantity = $service->minutesAvailable;

        // Create the service transaction
        $serviceTransaction = ServiceTransaction::create([
            'user_id' => $request->user_id,
            'quantity' => $serviceQuantity,
            'type' => $request->type,
            'location' => $request->location_id,
            'service_id' => $request->service_id,
        ]);

        // Fetch the user profile
        $userProfile = User_profile::where('user_id', $request->user_id)->first();
        if (!$userProfile) {
            return response()->json(['error' => 'User profile not found'], 404);
        }

        // Check if the type is 'purchased' or 'used'
        $quantity = $serviceQuantity ?? 0; // Default to 0 if quantity is null
        if ($request->type === 'purchased') {
            // Increase the available balance
            $newAvailableBalance = $userProfile->available_balance + $quantity;
            $userProfile->update(['available_balance' => $newAvailableBalance]);
        } elseif ($request->type === 'used') {
            // Check if available balance is sufficient
            if ($userProfile->available_balance < $quantity) {
                return response()->json(['error' => 'Insufficient balance'], 422);
            }

            // Decrease the available balance
            $newAvailableBalance = $userProfile->available_balance - $quantity;
            $userProfile->update(['available_balance' => $newAvailableBalance]);
        }

        return response()->json(['message' => 'Service transaction created successfully', 'data' => $serviceTransaction], 201);
    }



    /**
     * @OA\Get(
     *     path="/api/service-transactions/{id}",
     *     summary="Get a specific service transaction by user_id",
     *     tags={"Service Transactions"},
     *     description="Retrieve the details of a specific service transaction.",
     *     @OA\Parameter(
     *         name="user_id",
     *         in="path",
     *         required=true,
     *         description="ID of the service transaction",
     *         @OA\Schema(type="integer")
     *     ),
     *     @OA\Response(
     *         response=200,
     *         description="Service transaction details"
     *     ),
     *     @OA\Response(
     *         response=404,
     *         description="Service transaction not found"
     *     )
     * )
     */
    public function show($id)
    {
        // Fetch the service transactions for the user
        $transactions = DB::table('service_transactions')
            ->where('user_id', $id)
            ->get();

        // Check if no transactions found
        if ($transactions->isEmpty()) {
            return response()->json(['error' => 'No service transactions found'], 404);
        }

        $result = [];

        // Loop through each transaction
        foreach ($transactions as $transaction) {
            $userId = $transaction->user_id;

            // Fetch the user profile data
            $userProfile = User_profile::select('user_id as _id', 'firstName', 'lastName', 'email', 'phone_number', 'available_balance', 'preferred_location')
                ->where('user_id', $userId)
                ->first();

            // If user profile not found, continue to the next transaction
            if (!$userProfile) {
                continue;
            }

            // Fetch the preferred location details
            $preferredLocation = Location::select('id as _id', 'name', 'address', 'city', 'phone_number', 'post_code')
                ->where('id', $userProfile->preferred_location)
                ->first();

            // Fetch the service details
            $service = Service::select('id as _id', 'serviceName', 'price')
                ->where('id', $transaction->service_id)
                ->first();

            // If service not found, continue to the next transaction
            if (!$service) {
                continue;
            }

            // Add the transaction data to the result array
            $result[] = [
                'user_details' => [
                    'id' => $userProfile->_id,
                    'firstName' => $userProfile->firstName,
                    'lastName' => $userProfile->lastName,
                    'email' => $userProfile->email,
                    'phone_number' => $userProfile->phone_number,
                    'available_balance' => $userProfile->available_balance,
                    'preferred_location' => $preferredLocation ? [
                        'id' => $preferredLocation->_id,
                        'name' => $preferredLocation->name,
                        'address' => $preferredLocation->address,
                        'city' => $preferredLocation->city,
                        'phone_number' => $preferredLocation->phone_number,
                        'post_code' => $preferredLocation->post_code,
                    ] : null, // Handle case where preferred location may not exist
                ],
                'service' => [
                    'id' => $service->_id,
                    'name' => $service->serviceName,
                    'price' => $service->price,
                ],
                'transaction' => [
                    'id' => $transaction->id,
                    'quantity' => $transaction->quantity,
                    'type' => $transaction->type,
                    'created_at' => $transaction->created_at,
                    'updated_at' => $transaction->updated_at,
                ],
            ];
        }

        // If no valid transactions were found, return an error
        if (empty($result)) {
            return response()->json(['error' => 'No valid service transactions found'], 404);
        }

        // Return the combined data as a JSON response
        return response()->json($result);
    }








    /**
     * @OA\Put(
     *     path="/api/service-transactions/{id}",
     *     summary="Update a service transaction",
     *     tags={"Service Transactions"},
     *     description="Update a service transaction in the database.",
     *     @OA\Parameter(
     *         name="id",
     *         in="path",
     *         required=true,
     *         description="ID of the service transaction",
     *         @OA\Schema(type="integer")
     *     ),
     *     @OA\RequestBody(
     *         required=false,
     *         @OA\JsonContent(
     *             @OA\Property(property="quantity", type="string", example="2"),
     *             @OA\Property(property="type", type="string", example="purchase"),
     *             @OA\Property(property="location", type="string", example="New York"),
     *             @OA\Property(property="service", type="string", example="Haircut")
     *         )
     *     ),
     *     @OA\Response(
     *         response=200,
     *         description="Service transaction updated successfully"
     *     ),
     *     @OA\Response(
     *         response=404,
     *         description="Service transaction not found"
     *     )
     * )
     */
    public function update(Request $request, $id)
    {
        $serviceTransaction = ServiceTransaction::find($id);

        if (!$serviceTransaction) {
            return response()->json(['message' => 'Service transaction not found'], 404);
        }

        $request->validate([
            'quantity' => 'nullable|string',
            'type' => 'nullable|string',
            'location' => 'nullable|string',
            'service' => 'nullable|string',
        ]);

        $serviceTransaction->update([
            'quantity' => $request->quantity ?? $serviceTransaction->quantity,
            'type' => $request->type ?? $serviceTransaction->type,
            'location' => $request->location ?? $serviceTransaction->location,
            'service' => $request->service ?? $serviceTransaction->service,
        ]);

        return response()->json(['message' => 'Service transaction updated successfully', 'data' => $serviceTransaction]);
    }

    /**
     * @OA\Delete(
     *     path="/api/service-transactions/{id}",
     *     summary="Delete a service transaction",
     *     tags={"Service Transactions"},
     *     description="Delete a service transaction from the database.",
     *     @OA\Parameter(
     *         name="id",
     *         in="path",
     *         required=true,
     *         description="ID of the service transaction",
     *         @OA\Schema(type="integer")
     *     ),
     *     @OA\Response(
     *         response=200,
     *         description="Service transaction deleted successfully"
     *     ),
     *     @OA\Response(
     *         response=404,
     *         description="Service transaction not found"
     *     )
     * )
     */
    public function destroy($id)
    {
        $serviceTransaction = ServiceTransaction::find($id);

        if (!$serviceTransaction) {
            return response()->json(['message' => 'Service transaction not found'], 404);
        }

        // Retrieve the user profile associated with the service transaction
        $userProfile = User_Profile::find($serviceTransaction->user_id);

        if (!$userProfile) {
            return response()->json(['message' => 'User profile not found'], 404);
        }

        // Check the type of the transaction
        if ($serviceTransaction->type === 'purchased') {
            // Decrease the available balance by the quantity
            $userProfile->available_balance -= $serviceTransaction->quantity;
            $userProfile->save();
        } elseif ($serviceTransaction->type === 'used') {
            // Check if the available balance is sufficient
            if ($userProfile->available_balance < $serviceTransaction->quantity) {
                return response()->json(['message' => 'Insufficient balance'], 400);
            }
            // Decrease the available balance by the quantity
            $userProfile->available_balance -= $serviceTransaction->quantity;
            $userProfile->save();
        }

        // Delete the service transaction
        $serviceTransaction->delete();
        return response()->json(['message' => 'Service transaction deleted successfully']);
    }

    /**
     * @OA\Post(
     *     path="/api/total-spend/{userId}",
     *     summary="Calculate total spend after last purchase",
     *     tags={"Service Transactions"},
     *     description="Get the total quantity spent by the user after their last purchase date and update the total_spend field in the user profile.",
     *     @OA\Parameter(
     *         name="userId",
     *         in="path",
     *         required=true,
     *         @OA\Schema(type="integer"),
     *         description="The ID of the user"
     *     ),
     *     @OA\RequestBody(
     *         required=false,
     *         @OA\JsonContent(
     *
     *         )
     *     ),
     *     @OA\Response(
     *         response=200,
     *         description="Total spend updated successfully",
     *         @OA\JsonContent(
     *             @OA\Property(property="message", type="string", example="Total spend updated successfully"),
     *             @OA\Property(property="total_spend", type="integer", example=10)
     *         )
     *     ),
     *     @OA\Response(
     *         response=404,
     *         description="User profile or purchase transaction not found",
     *         @OA\JsonContent(
     *             @OA\Property(property="message", type="string", example="No purchase transactions found for this user.")
     *         )
     *     )
     * )
     */
    public function totalSpend($userId)
    {
        // Fetch the last purchase date for the user
        $lastPurchaseTransaction = ServiceTransaction::where('user_id', $userId)
            ->where('type', 'purchased')
            ->orderBy('created_at', 'desc')
            ->first();

        if (!$lastPurchaseTransaction) {
            return response()->json(['message' => 'No purchase transactions found for this user.'], 404);
        }

        // Get the last purchase date
        $lastPurchaseDate = $lastPurchaseTransaction->created_at;

        // Get all usage transactions after the last purchase date
        $usedTransactions = ServiceTransaction::where('user_id', $userId)
            ->where('type', 'used')
            ->where('created_at', '>=', $lastPurchaseDate)
            ->get();

        // Calculate total quantity spent
        $totalSpendQuantity = $usedTransactions->sum('quantity');

        // Update the total_spend field in user_profile
        $userProfile = User_profile::find($userId);

        if (!$userProfile) {
            return response()->json(['message' => 'User profile not found.'], 404);
        }

        // Update the total_spend field
        $userProfile->total_spend += $totalSpendQuantity;
        $userProfile->save();

        return response()->json(['message' => 'Total spend updated successfully', 'total_spend' => $userProfile->total_spend], 200);
    }

    public function minuteUsed($id = null)
    {
        // Check if an ID is provided
        if ($id) {
            // Calculate the sum of the quantity field for the specified user ID and type 'used'
            $totalUsed = ServiceTransaction::where('user_id', $id)
                ->where('type', 'used')
                ->sum('quantity');

            // Calculate the sum of the quantity field for the specified user ID and type 'purchased'
            $totalPurchased = ServiceTransaction::where('user_id', $id)
                ->where('type', 'purchased')
                ->sum('quantity');
        } else {
            // Calculate the sum of the quantity field for all users where type is 'used'
            $totalUsed = ServiceTransaction::where('type', 'used')->sum('quantity');

            // Calculate the sum of the quantity field for all users where type is 'purchased'
            $totalPurchased = ServiceTransaction::where('type', 'purchased')->sum('quantity');
        }

        // Prepare the response data
        $totalQuantity = [
            'totalUsed' => $totalUsed,
            'totalPurchased' => $totalPurchased
        ];

        // Return the response in JSON format
        return response()->json(['total_quantity' => $totalQuantity]);
    }
}
